=== DC - Facebook Like Popup ===
Contributors: dattardwp-21
Donate link: http://http://www.dart-creations.com/joomla-25-and-joomla-3-modules/75-donate-a-beer
Tags: wordpress, facebook, like, popin, responsive
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This Wordpress plugin helps you add Facebook Fans by popping up a window with a Facebook Like box. 

== Description ==

Our highly customizable plugin / enables you to create a Facebook Like box on your Wordpress site to increase the number of Facebook Fans. This popup is not blocked by normal pop-up blockers because it is a jQuery popup rather than a new window. It is highly configurable to allow to show it where you want, and as often as you want. You can also choose whether you want to show it to ALL users, logged in users only, or logged out users only.

This is a Facebook Like Popin window Wordpress plugin provided by [DART Creations](http://www.dart-creations.com/ "Your favorite Wordpress plugins")

The Facebook Like plugin offers the following features and customizations:

* Ability to enable / disable the Facebook like window at will
* Customize the text of "Follow us on Facebook" or whatever you prefer
* Choose whether or not to show the last post on your Facebook page
* Choose whether to show the plugin on the following pages / sections (Home, Posts, Pages, Everywhere else)
* Ability to disable the Facebook popin in any page using a shortcode in the Post Editor
* Choose whether to show it to Logged in Users or Logged out Users.
* Choose whether you ALWAYS want to show the plugin or how often you would like to show the plugin
* Define the number of seconds between showing the popup
* Choose whether you want to lock the scrolling ability whilst the popup is showing

== Installation ==

To install the module, simple go to (Plugins > Add New> Upload Plugin), choose the file you have downloaded above and click on the upload and install button. Use it by going to Settings > Facebook popup and specifying all the options as necessary

== Frequently Asked Questions ==

= Do you have any FAQs? =

Not yet - we will populate them as we go.

== Screenshots ==

1. This screen shot shows how the Facebook Like Box popup looks when it is open
2. This screen shot shows all the configuration options of the Wordpress Facebook Like Box popup 

== Changelog ==

= 1.0 =
* Released first version